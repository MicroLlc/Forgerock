<!--
  The contents of this file are subject to the terms of the Common Development and
  Distribution License (the License). You may not use this file except in compliance with the
  License.

  You can obtain a copy of the License at legal/CDDLv1.0.txt. See the License for the
  specific language governing permission and limitations under the License.

  When distributing Covered Software, include this CDDL Header Notice in each file and include
  the License file at legal/CDDLv1.0.txt. If applicable, add the following below the CDDL
  Header, with the fields enclosed by brackets [] replaced by your own identifying
  information: "Portions Copyright [year] [name of copyright owner]".

  Copyright 2016-2020 ForgeRock AS.
-->
# Example Password Storage Scheme

This folder contains source code for an example password storage scheme extension.
The example extension base64-encodes the user password and prefixes it with `{SAMPLE}`.

The configuration for the extension registers it with the server.

To build and use this example, perform the following steps:

1. Unpack and install, but do not start, a directory server:

```
DEPLOYMENT_ID=`/path/to/opendj/bin/dskeymgr create-deployment-id --deploymentIdPassword password

/path/to/opendj/setup \
    --deploymentId $DEPLOYMENT_ID
    --deploymentIdPassword password \
    --rootUserDn "uid=admin" \
    --rootUserPassword password \
    --hostname localhost \
    --ldapPort 1389 \
    --adminConnectorPort 4444 \
    --profile ds-evaluation \
    --acceptLicense
```

2. Unzip the example password storage scheme extension distribution file:

```
unzip /path/to/opendj/samples/example-pwdscheme.zip -d /tmp
```

3. Build the example (requires Maven 3.6 and Java 17):

```
cd /tmp/opendj-server-example-pwdscheme
mvn clean install
```

4. Unzip the example extension you built:

```
unzip target/opendj-pwdscheme-extension-*.zip -d /tmp/
```

5. Copy the example distribution files into the server instance folder:

```
cd /path/to/opendj && cp -r /tmp/opendj-pwdscheme-extension-*/* .
```

This step copies the following files:

* `config/pwdscheme-sample-config.ldif`
* `db/schema/90-pwdscheme-extension.ldif`
* `lib/extensions/opendj-pwdscheme-extension-*.jar`
* `README.md`

6. Add the example password storage scheme configuration to the server configuration:

```
./bin/dsconfig create-password-storage-scheme \
    --offline \
    --scheme-name Sample\ Pwd\ Scheme \
    --type sample \
    --set enabled:true \
    --no-prompt
```

If you now use the `dsconfig` command in interactive mode,
you see that the "Sample Pwd Scheme" is listed as a password storage scheme.

8. Verify that the extension works by encoding a password using the new scheme:

```
./bin/encode-password -s SAMPLE -c password
{SAMPLE}cGFzc3dvcmQ=
```

You can also now create password policies that use your new scheme.
